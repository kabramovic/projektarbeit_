def add_five(number):
    return number + 5

def add_twenty(number):
    return number + 20